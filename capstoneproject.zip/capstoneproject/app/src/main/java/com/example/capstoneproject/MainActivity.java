package com.example.capstoneproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    // Use HTTP for localhost, HTTPS only for real servers
    private static final String SERVER_URL = "http://10.0.2.2/store_click.php"; // Change to HTTPS if needed
    private Button btnAdminLogin, btnTeacherLogin, btnStudentLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Disable SSL check (For debugging only!)
        SSLHelper.disableSSLCertificateChecking();

        // Initialize Buttons
        btnAdminLogin = findViewById(R.id.btnAdminLogin);
        btnTeacherLogin = findViewById(R.id.btnTeacherLogin);
        btnStudentLogin = findViewById(R.id.btnStudentLogin);

        // Click Listeners
        btnAdminLogin.setOnClickListener(v -> handleLogin("ADMIN", loginadmin.class));
        btnTeacherLogin.setOnClickListener(v -> handleLogin("TEACHER", loginteacher.class));
        btnStudentLogin.setOnClickListener(v -> handleLogin("STUDENT", loginstudent.class));
    }

    private void handleLogin(String userType, Class<?> activityClass) {
        Toast.makeText(this, userType + " Login Clicked!", Toast.LENGTH_SHORT).show();
        sendButtonClick(userType);
        openLoginActivity(activityClass);
    }

    private void sendButtonClick(String userType) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(SERVER_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String postData = "user_type=" + URLEncoder.encode(userType, "UTF-8");

                try (OutputStream os = connection.getOutputStream();
                     BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"))) {
                    writer.write(postData);
                    writer.flush();
                }

                int responseCode = connection.getResponseCode();
                Log.e("API Response", "Response Code: " + responseCode);

                StringBuilder response = new StringBuilder();
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                }

                Log.d("API Response", "Response Data: " + response.toString());

                runOnUiThread(() -> {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Server Response")
                            .setMessage(response.toString())
                            .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                            .show();
                });

            } catch (Exception e) {
                Log.e("API Error", "Exception: " + e.getMessage());
                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this, "Server Error: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
            }
        });
    }

    private void openLoginActivity(Class<?> activityClass) {
        Intent intent = new Intent(MainActivity.this, activityClass);
        startActivity(intent);
    }
}
