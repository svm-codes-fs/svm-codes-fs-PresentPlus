package com.example.capstoneproject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class calender extends AppCompatActivity {

    private static final int REQUEST_CODE = 1; // Request code for file selection

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender); // Make sure this matches your XML layout file name

        // Find the Upload Calendar button by its ID
        Button uploadCalendarButton = findViewById(R.id.uploadCalendarButton);

        // Set an OnClickListener to handle the Upload Calendar button click
        uploadCalendarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call the method to show the dialog box
                showFileManagerDialog();
            }
        });

        // Find the Delete Calendar button by its ID
        Button deleteCalendarButton = findViewById(R.id.deleteCalendarButton);

        // Set an OnClickListener to handle the Delete Calendar button click
        deleteCalendarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add functionality for the Delete Calendar button here
                Toast.makeText(calender.this, "Delete Calendar Clicked", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to show the dialog box with a File Manager button
    private void showFileManagerDialog() {
        // Create an AlertDialog.Builder instance
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Upload Calendar"); // Set the title of the dialog
        builder.setMessage("Select a file to upload."); // Set the message of the dialog

        // Add a File Manager button to the dialog
        builder.setPositiveButton("File Manager", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle the File Manager button click
                openFileManager();
            }
        });

        // Add a Cancel button to the dialog
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Dismiss the dialog
                dialog.dismiss();
            }
        });

        // Create and show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Method to handle the File Manager button click
    private void openFileManager() {
        // Create an Intent to open the file manager
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("/"); // Set the type to all files
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        // Start the file manager activity
        startActivityForResult(Intent.createChooser(intent, "Select a file"), REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                // Get the Uri of the selected file
                Uri uri;
            }
        }
    }
}
