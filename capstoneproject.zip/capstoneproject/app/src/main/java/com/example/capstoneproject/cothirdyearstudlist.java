package com.example.capstoneproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class cothirdyearstudlist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cothirdyearstudlist); // Replace with your XML layout file name

        // Submit Button
        Button submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(v -> {
            // Calculate attendance
            calculateAttendance();
        });
    }

    private void calculateAttendance() {
        // Array of all CheckBox IDs
        int[] checkBoxIds = {
                R.id.raj, R.id.ram, R.id.sita, R.id.sanika, R.id.vennela,
                R.id.pranali, R.id.omkar, R.id.himanshu, R.id.prajwal,
                R.id.khushi, R.id.jyotsana, R.id.priyanka
        };

        int totalStudents = checkBoxIds.length;
        int presentStudents = 0;
        int absentStudents = 0;

        // Loop through all CheckBoxes
        for (int id : checkBoxIds) {
            CheckBox checkBox = findViewById(id);
            if (checkBox.isChecked()) {
                presentStudents++;
            } else {
                absentStudents++;
            }
        }

        // Display the results in a Toast
        String message = "Total Students: " + totalStudents + "\n" +
                "Present: " + presentStudents + "\n" +
                "Absent: " + absentStudents;

        Toast.makeText(this, message, Toast.LENGTH_LONG).show();

        // Store the results in SharedPreferences
        storeAttendanceResults(totalStudents, presentStudents, absentStudents);
    }

    private void storeAttendanceResults(int totalStudents, int presentStudents, int absentStudents) {
        SharedPreferences sharedPreferences = getSharedPreferences("AttendanceData", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt("TotalStudents", totalStudents);
        editor.putInt("PresentStudents", presentStudents);
        editor.putInt("AbsentStudents", absentStudents);

        editor.apply(); // Save the data

        // Optional: Log the results for debugging
        System.out.println("Total Students: " + totalStudents);
        System.out.println("Present Students: " + presentStudents);
        System.out.println("Absent Students: " + absentStudents);
    }
}
