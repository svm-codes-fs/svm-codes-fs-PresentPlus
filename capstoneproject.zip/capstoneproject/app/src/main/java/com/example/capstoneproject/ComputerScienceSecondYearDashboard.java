package com.example.capstoneproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class ComputerScienceSecondYearDashboard extends AppCompatActivity {

    private Button viewTimeTableButton, notificationButton, viewAttendanceButton, leaveManageSystemButton;
    private ImageButton classroomButton;
    private ImageView profileImage;

    // Variables to store department and year
    private String department, year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_computer_science_second_year_dashboard);

        // Initialize Buttons
        viewTimeTableButton = findViewById(R.id.viewTimeTableButtonSecondYear);
        notificationButton = findViewById(R.id.notification_buttonSecondYear);
        viewAttendanceButton = findViewById(R.id.view_attendanceSecondYear);
        leaveManageSystemButton = findViewById(R.id.leaveManageSystemButtonSecondYear);
        profileImage = findViewById(R.id.profileImageViewSecondYear);
        classroomButton = findViewById(R.id.classroomButtonSecondYear);

        // Get department and year from the login activity
        Intent intent = getIntent();
        department = intent.getStringExtra("DEPARTMENT");
        year = intent.getStringExtra("YEAR");

        // Load Profile Image
        loadProfileImage();

        // Button Click Listeners
        viewTimeTableButton.setOnClickListener(v -> startActivity(new Intent(ComputerScienceSecondYearDashboard.this, cosecondyearstudtimetable.class)));
        notificationButton.setOnClickListener(v -> openNotifications());
        viewAttendanceButton.setOnClickListener(v -> startActivity(new Intent(ComputerScienceSecondYearDashboard.this, cosecondyearstudviewattendance.class)));
        leaveManageSystemButton.setOnClickListener(v -> startActivity(new Intent(ComputerScienceSecondYearDashboard.this, cosecondyearstudleavemanagementsystem.class)));

        // Open Profile Page
        profileImage.setOnClickListener(v -> startActivity(new Intent(ComputerScienceSecondYearDashboard.this, cosecondyearstudprofile.class)));

        classroomButton.setOnClickListener(v -> startActivity(new Intent(ComputerScienceSecondYearDashboard.this, cosecondyearstudclassroom.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProfileImage(); // Refresh profile image on return
    }

    private void loadProfileImage() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE);
        String encodedImage = sharedPreferences.getString("profile_image", "");

        if (!encodedImage.isEmpty()) {
            byte[] decodedBytes = Base64.decode(encodedImage, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
            profileImage.setImageBitmap(bitmap);
        }
    }

    private void openNotifications() {
        // Pass year to the Computer Science Announcement activity
        Intent intent = new Intent(ComputerScienceSecondYearDashboard.this, cosecondyearAnnouncement.class);
        intent.putExtra("YEAR", year); // Pass year
        startActivity(intent);
    }
}