package com.example.capstoneproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class loginadmin extends AppCompatActivity {

    private static final String TAG = "AdminLogin";
    private static final String LOGIN_URL = "http://presentplusbcpc.infinityfreeapp.com/login_admin.php";
    private static final String FIXED_SPECIAL_CODE = "BCPC0109";
    private static final int CONNECTION_TIMEOUT = 15;

    private EditText usernameEditText, passwordEditText, specialCodeEditText;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginadmin);

        initializeViews();
        setupLoginButton();
    }

    private void initializeViews() {
        usernameEditText = findViewById(R.id.usernameInput);
        passwordEditText = findViewById(R.id.passwordInput);
        specialCodeEditText = findViewById(R.id.specialCodeInput);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Logging in...");
        progressDialog.setCancelable(false);
    }

    private void setupLoginButton() {
        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String specialCode = specialCodeEditText.getText().toString().trim();

        if (validateInputs(username, password, specialCode)) {
            performLoginRequest(username, password, specialCode);
        }
    }

    private boolean validateInputs(String username, String password, String specialCode) {
        if (username.isEmpty()) {
            usernameEditText.setError("Username is required");
            return false;
        }
        if (password.isEmpty()) {
            passwordEditText.setError("Password is required");
            return false;
        }
        if (specialCode.isEmpty()) {
            specialCodeEditText.setError("Special code is required");
            return false;
        }
        if (!specialCode.equals(FIXED_SPECIAL_CODE)) {
            specialCodeEditText.setError("Invalid special code");
            return false;
        }
        return true;
    }

    private void performLoginRequest(String username, String password, String specialCode) {
        progressDialog.show();

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(CONNECTION_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(CONNECTION_TIMEOUT, TimeUnit.SECONDS)
                .build();

        RequestBody body = new FormBody.Builder()
                .add("username", username)
                .add("password", password)
                .add("special_code", specialCode)
                .build();

        Request request = new Request.Builder()
                .url(LOGIN_URL)
                .post(body)
                .addHeader("Accept", "application/json")
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    showToast("Network error: " + e.getMessage());
                    Log.e(TAG, "Network error", e);
                });
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                runOnUiThread(() -> progressDialog.dismiss());

                if (!response.isSuccessful()) {
                    runOnUiThread(() -> showToast("Server error: " + response.message()));
                    return;
                }

                try {
                    String responseBody = response.body().string();
                    processLoginResponse(responseBody, username);
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing response", e);
                }
            }
        });
    }

    private void processLoginResponse(String response, String username) {
        Log.d(TAG, "Raw server response: " + response);

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String status = jsonResponse.optString("status", "error");
            String message = jsonResponse.optString("message", "No message from server");

            if ("success".equalsIgnoreCase(status)) {
                handleSuccessfulLogin(username);
            } else {
                runOnUiThread(() -> showToast("Login failed: " + message));
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSON parsing error: " + response, e);
            runOnUiThread(() -> showToast("Invalid server response. Check server logs."));
        }
    }

    private void handleSuccessfulLogin(String username) {
        runOnUiThread(() -> {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, admindashboard.class)
                    .putExtra("USERNAME", username));
            finish();
        });
    }

    private void showToast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }
}