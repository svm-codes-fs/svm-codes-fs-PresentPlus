package com.example.capstoneproject;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

public class adminprofile extends AppCompatActivity {

    private TextView usernameTextView, descriptionTextView, mobileTextView, emailTextView;
    private TextInputLayout descriptionInputLayout, mobileInputLayout, emailInputLayout;
    private TextInputEditText descriptionEditText, mobileEditText, emailEditText;
    private FloatingActionButton changeProfileImageButton;
    private Button editProfileButton, saveButton;
    private ImageView profileImageView;

    private boolean isEditMode = false;

    private static final int REQUEST_CAMERA = 1;
    private static final int REQUEST_GALLERY = 2;
    private static final int CAMERA_PERMISSION_CODE = 100;

    private static final String PREFS_NAME = "ProfilePrefs";
    private static final String PROFILE_IMAGE_KEY = "ProfileImage";

    private SharedPreferences sharedPreferences;
    private Uri imageUri;

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminprofile);

        // Initialize views
        usernameTextView = findViewById(R.id.usernametextView);
        descriptionTextView = findViewById(R.id.descriptiontextView);
        mobileTextView = findViewById(R.id.mobiletextView);
        emailTextView = findViewById(R.id.emailtextView);
        descriptionInputLayout = findViewById(R.id.descriptioninputLayout);
        mobileInputLayout = findViewById(R.id.mobileinputLayout);
        emailInputLayout = findViewById(R.id.emailinputLayout);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        mobileEditText = findViewById(R.id.mobileEditText);
        emailEditText = findViewById(R.id.emaileditText);
        changeProfileImageButton = findViewById(R.id.changeprofileImageButton);
        editProfileButton = findViewById(R.id.editprofileButton);
        saveButton = findViewById(R.id.savebutton);
        profileImageView = findViewById(R.id.profile);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Load profile image
        loadProfileImage();

        // Get username from intent
        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");
        usernameTextView.setText(username != null && !username.isEmpty() ? username : "Admin");

        // Set up buttons
        editProfileButton.setOnClickListener(v -> toggleEditMode());
        saveButton.setOnClickListener(v -> saveProfileChanges());
        changeProfileImageButton.setOnClickListener(v -> showImagePickerDialog());

        // Go back to Admin Dashboard when clicking profile image
        profileImageView.setOnClickListener(v -> {
            Intent dashboardIntent = new Intent(adminprofile.this, admindashboard.class);
            startActivity(dashboardIntent);
            finish();
        });
    }

    private void toggleEditMode() {
        isEditMode = !isEditMode;

        if (isEditMode) {
            descriptionTextView.setVisibility(View.GONE);
            mobileTextView.setVisibility(View.GONE);
            emailTextView.setVisibility(View.GONE);
            descriptionInputLayout.setVisibility(View.VISIBLE);
            mobileInputLayout.setVisibility(View.VISIBLE);
            emailInputLayout.setVisibility(View.VISIBLE);
            editProfileButton.setVisibility(View.GONE);
            saveButton.setVisibility(View.VISIBLE);

            // Populate EditText fields
            descriptionEditText.setText(descriptionTextView.getText());
            mobileEditText.setText(mobileTextView.getText());
            emailEditText.setText(emailTextView.getText());
        } else {
            descriptionTextView.setVisibility(View.VISIBLE);
            mobileTextView.setVisibility(View.VISIBLE);
            emailTextView.setVisibility(View.VISIBLE);
            descriptionInputLayout.setVisibility(View.GONE);
            mobileInputLayout.setVisibility(View.GONE);
            emailInputLayout.setVisibility(View.GONE);
            editProfileButton.setVisibility(View.VISIBLE);
            saveButton.setVisibility(View.GONE);
        }
    }

    private void saveProfileChanges() {
        descriptionTextView.setText(descriptionEditText.getText().toString().trim());
        mobileTextView.setText(mobileEditText.getText().toString().trim());
        emailTextView.setText(emailEditText.getText().toString().trim());
        Toast.makeText(this, "Profile changes saved!", Toast.LENGTH_SHORT).show();
        toggleEditMode();
    }

    private void showImagePickerDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Profile Image")
                .setItems(new String[]{"📷 Camera", "🖼️ Gallery"}, (dialog, which) -> {
                    if (which == 0) {
                        openCamera();
                    } else {
                        openGallery();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
        } else {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            File photoFile = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "profile_photo.jpg");
            imageUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".fileprovider", photoFile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            startActivityForResult(intent, REQUEST_CAMERA);
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            Bitmap bitmap = null;

            if (requestCode == REQUEST_CAMERA) {
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (requestCode == REQUEST_GALLERY && data != null) {
                Uri selectedImageUri = data.getData();
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (bitmap != null) {
                profileImageView.setImageBitmap(bitmap);
                saveProfileImage(bitmap);
            }
        }
    }
    private void saveProfileImage(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        String encodedImage = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("profile_image_base64", encodedImage);
        editor.apply();
    }


    private void loadProfileImage() {
        String encodedImage = sharedPreferences.getString(PROFILE_IMAGE_KEY, null);
        if (encodedImage != null) {
            byte[] decodedBytes = Base64.decode(encodedImage, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
            profileImageView.setImageBitmap(bitmap);
        }
    }
}
