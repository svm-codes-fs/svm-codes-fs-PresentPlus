package com.example.capstoneproject;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class cofirstyearAnnouncement extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NotificationAdapter adapter;
    private ArrayList<NotificationModel> notificationList;
    private static final String FETCH_URL = "http://10.0.2.2/get_notification.php"; // Update with actual URL

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cofirstyear_announcement);

        recyclerView = findViewById(R.id.recyclerViewNotifications);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize notification list
        notificationList = new ArrayList<>();

        // Initialize adapter with empty list
        adapter = new NotificationAdapter(this, notificationList);
        recyclerView.setAdapter(adapter);

        fetchNotifications();
    }

    private void fetchNotifications() {
        StringRequest request = new StringRequest(Request.Method.POST, FETCH_URL,
                response -> {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        if (jsonResponse.getBoolean("success")) {
                            JSONArray notificationsArray = jsonResponse.getJSONArray("notifications");

                            // Clear list before adding new items
                            notificationList.clear();

                            for (int i = 0; i < notificationsArray.length(); i++) {
                                JSONObject obj = notificationsArray.getJSONObject(i);
                                notificationList.add(new NotificationModel(
                                        obj.getString("message"),
                                        obj.getString("timestamp")
                                ));
                            }
                            // Notify adapter about data change
                            adapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(this, "No Notifications Found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "JSON Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    Toast.makeText(this, "Network Error: " + error.toString(), Toast.LENGTH_LONG).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("department", "Computer Science"); // Use correct department code (CO)
                params.put("year", "1st Year"); // Ensure format is correct
                return params;
            }
        };

        // Add request to queue
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }
}
