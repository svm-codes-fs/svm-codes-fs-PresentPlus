package com.example.capstoneproject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class loginstudent extends AppCompatActivity {
    private static final String LOGIN_URL = "http://10.0.2.2/login.php";
    private static final String REGISTER_URL = "http://10.0.2.2/register_user.php";
    EditText username, password, rollNumber;
    AutoCompleteTextView departmentDropdown;
    RadioGroup yearGroup;
    Button loginButton;
    TextView forgotPassword;
    ProgressDialog progressDialog;
    String[] departments = {"Select Department", "Computer Science", "Mechanical", "Civil", "Electrical", "Electronics", "Mining"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginstudent);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        rollNumber = findViewById(R.id.roll_no);
        departmentDropdown = findViewById(R.id.department_dropdown);
        yearGroup = findViewById(R.id.year_radio_group);
        loginButton = findViewById(R.id.loginButton);
        forgotPassword = findViewById(R.id.forgotPassword);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, departments);
        departmentDropdown.setAdapter(adapter);
        departmentDropdown.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                departmentDropdown.showDropDown();
            }
            return false;
        });

        loginButton.setOnClickListener(v -> loginUser());

        forgotPassword.setOnClickListener(v -> {
            Intent intent = new Intent(loginstudent.this, ForgotPasswordActivity.class);
            startActivity(intent);
        });
    }

    private void loginUser() {
        String user = username.getText().toString().trim();
        String pass = password.getText().toString().trim();
        String rollNo = rollNumber.getText().toString().trim();
        String department = departmentDropdown.getText().toString().trim();
        int selectedYearId = yearGroup.getCheckedRadioButtonId();

        if (user.isEmpty() || pass.isEmpty() || rollNo.isEmpty() || department.isEmpty() || selectedYearId == -1) {
            Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
            return;
        }

        RadioButton selectedYear = findViewById(selectedYearId);
        String year = selectedYear.getText().toString().trim();

        if (!isNetworkAvailable()) {
            Toast.makeText(this, "No Internet Connection", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.show();
        loginButton.setEnabled(false);

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("username", user);
            jsonBody.put("password", pass);
            jsonBody.put("roll_no", rollNo);
            jsonBody.put("department", department);
            jsonBody.put("year", year);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, LOGIN_URL, jsonBody,
                response -> {
                    progressDialog.dismiss();
                    loginButton.setEnabled(true);
                    Log.d("API_RESPONSE", "Raw Response: " + response.toString());

                    String status = response.optString("status", "error");
                    String message = response.optString("message", "Invalid Response");
                    Toast.makeText(loginstudent.this, message, Toast.LENGTH_SHORT).show();

                    if ("success".equals(status)) {
                        // Navigate to the appropriate dashboard based on department and year
                        navigateToDashboard(department, year);
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    loginButton.setEnabled(true);
                    Log.e("API_ERROR", "Volley Error: ", error);
                    Toast.makeText(loginstudent.this, "Connection Error. Please try again!", Toast.LENGTH_LONG).show();
                });
        queue.add(request);
    }

    private void navigateToDashboard(String department, String year) {
        Intent intent;

        // Example: Navigate to Computer Science dashboards
        if (department.equals("Computer Science")) {
            switch (year) {
                case "1st Year":
                    intent = new Intent(loginstudent.this, ComputerScienceFirstYearDashboard.class);
                    break;
                case "2nd Year":
                    intent = new Intent(loginstudent.this, ComputerScienceSecondYearDashboard.class);
                    break;
                case "3rd Year":
                    intent = new Intent(loginstudent.this, ComputerScienceThirdYearDashboard.class);
                    break;
                default:
                    Toast.makeText(this, "Invalid year selected", Toast.LENGTH_SHORT).show();
                    return;
            }
        } else {
            // Default to a generic student dashboard
            intent = new Intent(loginstudent.this, ComputerScienceThirdYearDashboard.class);
        }

        // Pass department and year to the dashboard
        intent.putExtra("DEPARTMENT", department);
        intent.putExtra("YEAR", year);
        startActivity(intent);
        finish();
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnected();
    }
}