package com.example.capstoneproject;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class cosecondyearstudtimetable extends AppCompatActivity {

    private ImageView timetableImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studtimetable); // XML Layout for Timetable View

        // Initialize ImageView
        timetableImageView = findViewById(R.id.timetableImageView);

        // Simulate loading the timetable image from assets or URL
        loadTimetableImage();
    }

    // Function to load timetable image into ImageView
    private void loadTimetableImage() {
        // Load the timetable image from the assets folder or URL using Glide
        // If you store your images in the assets folder:

        // Replace with actual file name


        // If you want to load the image from a URL, you can use:
        // Glide.with(this)
        //        .load("https://your-server-url.com/timetable_image.png") // Replace with actual URL
        //        .into(timetableImageView);

        Toast.makeText(this, "Timetable Loaded", Toast.LENGTH_SHORT).show();
    }
}
