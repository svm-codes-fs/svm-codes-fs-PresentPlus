package com.example.capstoneproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.LinkedList;
import java.util.List;

public class admindashboard extends AppCompatActivity {
    private List<String> recentActivities = new LinkedList<>();
    private TextView recentActivity1, recentActivity2, recentActivity3, recentNotificationActivity;
    private ImageButton adminProfileButton;
    private String username; // Store the username

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admindashboard);

        // Get username from login page
        Intent intent = getIntent();
        username = intent.getStringExtra("USERNAME");

        // Initialize UI elements
        recentActivity1 = findViewById(R.id.recentActivity1);
        recentActivity2 = findViewById(R.id.recentActivity2);
        recentActivity3 = findViewById(R.id.recentActivity3);
        recentNotificationActivity = findViewById(R.id.recentNotificationActivity);
        adminProfileButton = findViewById(R.id.profileButton);

        // Load profile image
        loadProfileImage();

        // Click listener for admin profile button
        adminProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(admindashboard.this, adminprofile.class);
                startActivity(intent);
            }
        });

        // Other buttons for navigation
        Button deptRecordsButton = findViewById(R.id.deptRecordsButton);
        deptRecordsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateRecentActivities("Viewed Dept Records");
                startActivity(new Intent(admindashboard.this, DeptRecordsActivity.class));
            }
        });

        Button notificationButton = findViewById(R.id.notificationButton);
        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateRecentActivities("Sent Notification");
                startActivity(new Intent(admindashboard.this, adminNotification.class));
            }
        });

        ImageButton academicCalendarButton = findViewById(R.id.academicCalendarButton);
        academicCalendarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateRecentActivities("Checked Academic Calendar");
                startActivity(new Intent(admindashboard.this, calender.class));
            }
        });

        // Initialize with Default Recent Activities
        updateRecentActivities("New Notification: Department Records have been updated.");
    }

    private void loadProfileImage() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String encodedImage = prefs.getString("profile_image_base64", null);

        if (encodedImage != null) {
            byte[] decodedBytes = Base64.decode(encodedImage, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
            Bitmap circularBitmap = getCircularBitmap(bitmap);
            adminProfileButton.setImageBitmap(circularBitmap);
        } else {
            adminProfileButton.setImageResource(R.drawable.profile); // Default image
        }
    }

    // Helper function to make image circular
    private Bitmap getCircularBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int size = Math.min(width, height);
        Bitmap output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(output);
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, size, size);
        final RectF rectF = new RectF(rect);

        paint.setAntiAlias(true);
        canvas.drawOval(rectF, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;
    }
    @Override
    protected void onResume() {
        super.onResume();
        loadProfileImage(); // Refresh image when returning to dashboard
    }

    private void updateRecentActivities(String newActivity) {
        // Add new activity at the top
        recentActivities.add(0, newActivity);

        // Ensure only last 4 activities are shown
        while (recentActivities.size() > 4) {
            recentActivities.remove(recentActivities.size() - 1);
        }

        // Update UI
        if (recentActivities.size() > 0) recentActivity1.setText(recentActivities.get(0));
        if (recentActivities.size() > 1) recentActivity2.setText(recentActivities.get(1));
        if (recentActivities.size() > 2) recentActivity3.setText(recentActivities.get(2));
        if (recentActivities.size() > 3)
            recentNotificationActivity.setText(recentActivities.get(3));
    }
}
