package com.example.capstoneproject;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class adminNotification extends AppCompatActivity {

    private static final int PICK_FILE_REQUEST = 1;
    private Spinner departmentSpinner, yearSpinner;
    private Button btnSend, btnUploadFile, btnDelete;
    private EditText messageEditText;

    private static final String SEND_NOTIFICATION_URL = "http://10.0.2.2/send_notification.php"; // Replace with actual URL

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_notification);

        departmentSpinner = findViewById(R.id.departmentSpinner);
        yearSpinner = findViewById(R.id.yearSpinner);
        btnSend = findViewById(R.id.btn_upload);
        btnUploadFile = findViewById(R.id.btn_upload_file);
        btnDelete = findViewById(R.id.btn_delete);
        messageEditText = findViewById(R.id.messageEditText);

        setupSpinners();

        btnSend.setOnClickListener(v -> sendNotification());
        btnUploadFile.setOnClickListener(v -> showUploadDialog());
        btnDelete.setOnClickListener(v -> onDeleteButtonClicked());
    }

    private void onDeleteButtonClicked() {

    }

    private void setupSpinners() {
        String[] departments = {"Select Department", "Computer Science", "Mechanical", "Civil", "Electrical", "Electronics", "Mining"};
        ArrayAdapter<String> departmentAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, departments);
        departmentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        departmentSpinner.setAdapter(departmentAdapter);

        String[] years = {"Select Year", "1st Year", "2nd Year", "3rd Year"};
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, years);
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearSpinner.setAdapter(yearAdapter);
    }

    private void sendNotification() {
        String department = departmentSpinner.getSelectedItem().toString();
        String year = yearSpinner.getSelectedItem().toString();
        String message = messageEditText.getText().toString().trim();

        if (department.equals("Select Department") || year.equals("Select Year") || message.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, String> params = new HashMap<>();
        params.put("department", department);
        params.put("year", year);
        params.put("message", message);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, SEND_NOTIFICATION_URL, new JSONObject(params),
                response -> {
                    try {
                        String status = response.getString("status");
                        if (status.equals("success")) {
                            Toast.makeText(adminNotification.this, "Notification Sent!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(adminNotification.this, "Error: " + response.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    Log.e("Volley", "Error: " + error.toString());
                    Toast.makeText(adminNotification.this, "Failed to send notification", Toast.LENGTH_SHORT).show();
                });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);

        messageEditText.setText("");
    }

    private void showUploadDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_upload_media);
        dialog.setCancelable(true);

        Button btnPickMedia = dialog.findViewById(R.id.btn_pick_media);
        btnPickMedia.setOnClickListener(v -> {
            pickFile();
            dialog.dismiss();
        });

        dialog.show();
    }

    private void pickFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }
}
