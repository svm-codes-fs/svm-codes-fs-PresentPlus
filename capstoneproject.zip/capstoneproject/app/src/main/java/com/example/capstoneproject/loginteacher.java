package com.example.capstoneproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class loginteacher extends AppCompatActivity {

    private EditText username, password, specialCode;
    private AutoCompleteTextView departmentDropdown;
    private RadioGroup roleGroup;
    private Button loginButton;
    private ProgressDialog progressDialog;

    private static final String LOGIN_URL = "http://10.0.2.2/login_teacher.php";
    private static final String REGISTER_URL = "http://10.0.2.2/register_teacher.php";

    String[] departments = {"Computer Science", "Mechanical", "Civil", "Electrical", "Electronics", "Mining"};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginteacher);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        departmentDropdown = findViewById(R.id.department_dropdown);
        specialCode = findViewById(R.id.code);
        roleGroup = findViewById(R.id.roleGroup);
        loginButton = findViewById(R.id.loginButton);
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        setupDepartmentDropdown();

        loginButton.setOnClickListener(v -> attemptLogin());
    }

    private void setupDepartmentDropdown() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, departments);
        departmentDropdown.setAdapter(adapter);
        departmentDropdown.setFocusable(false);
        departmentDropdown.setOnClickListener(v -> departmentDropdown.showDropDown());
    }

    private void attemptLogin() {
        String user = username.getText().toString().trim();
        String pass = password.getText().toString().trim();
        String department = departmentDropdown.getText().toString().trim();
        String code = specialCode.getText().toString().trim();

        int selectedRoleId = roleGroup.getCheckedRadioButtonId();
        if (selectedRoleId == -1) {
            Toast.makeText(this, "Please select a role!", Toast.LENGTH_SHORT).show();
            return;
        }
        RadioButton selectedRoleButton = findViewById(selectedRoleId);
        String role = selectedRoleButton.getText().toString().trim();

        if (user.isEmpty() || pass.isEmpty() || department.isEmpty() || code.isEmpty() || role.isEmpty()) {
            Toast.makeText(this, "Please fill all fields!", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.setMessage("Logging in...");
        progressDialog.show();

        // Try login first
        StringRequest loginRequest = new StringRequest(Request.Method.POST, LOGIN_URL,
                response -> {
                    progressDialog.dismiss();
                    handleLoginResponse(response, user, department, role, pass, code);
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Network Error! " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", user);
                params.put("password", pass);
                params.put("department", department);
                params.put("role", role);
                params.put("special_code", code);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(loginRequest);
    }

    private void handleLoginResponse(String response, String username, String department, String role, String password, String code) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.getBoolean("success")) {
                navigateToProfile(username, department, role);
            } else {
                // If login fails, attempt registration
                attemptRegister(username, password, department, role, code);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Login Error!", Toast.LENGTH_SHORT).show();
        }
    }

    private void attemptRegister(String username, String password, String department, String role, String code) {
        progressDialog.setMessage("Registering...");
        progressDialog.show();

        StringRequest registerRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                response -> {
                    progressDialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getBoolean("success")) {
                            navigateToProfile(username, department, role);
                        } else {
                            Toast.makeText(this, "Registration Failed!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Registration Error!", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Network Error! " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                params.put("department", department);
                params.put("role", role);
                params.put("special_code", code);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(registerRequest);
    }

    private void navigateToProfile(String username, String department, String role) {
        Intent intent;

        if (role.equalsIgnoreCase("Teacher")) {
            intent = new Intent(loginteacher.this, teacherdashboard.class); // Open main dashboard first
        } else {
            Toast.makeText(this, "Only Teachers can access this profile!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Pass login data to the main dashboard
        intent.putExtra("username", username);
        intent.putExtra("department", department);
        intent.putExtra("role", role);

        startActivity(intent);
        finish();
    }
}
