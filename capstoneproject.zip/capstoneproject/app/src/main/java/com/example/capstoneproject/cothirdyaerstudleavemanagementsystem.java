package com.example.capstoneproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class cothirdyaerstudleavemanagementsystem extends AppCompatActivity {

    private EditText leaveTypeEditText, startDateEditText, endDateEditText, descriptionEditText, nameEditText, idEditText, mobileEditText;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studleavemanagementsystem); // Reference to the layout XML

        // Initialize EditText fields
        leaveTypeEditText = findViewById(R.id.leaveTypeEditText);
        startDateEditText = findViewById(R.id.startDateEditText);
        endDateEditText = findViewById(R.id.endDateEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        nameEditText = findViewById(R.id.nameEditText);
        idEditText = findViewById(R.id.idEditText);
        mobileEditText = findViewById(R.id.mobileEditText);

        // Initialize Submit Button
        submitButton = findViewById(R.id.submitButton);

        // Set OnClickListener for Submit Button
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Collect the data from all input fields
                String leaveType = leaveTypeEditText.getText().toString().trim();
                String startDate = startDateEditText.getText().toString().trim();
                String endDate = endDateEditText.getText().toString().trim();
                String description = descriptionEditText.getText().toString().trim();
                String name = nameEditText.getText().toString().trim();
                String id = idEditText.getText().toString().trim();
                String mobile = mobileEditText.getText().toString().trim();

                // Validate the input
                if (leaveType.isEmpty() || startDate.isEmpty() || endDate.isEmpty() || description.isEmpty() || name.isEmpty() || id.isEmpty() || mobile.isEmpty()) {
                    Toast.makeText(cothirdyaerstudleavemanagementsystem.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Simulate sending the leave application
                // You can replace this with your logic to send data (e.g., via an API call)
                Toast.makeText(cothirdyaerstudleavemanagementsystem.this, "Leave application sent to Teacher/HOD", Toast.LENGTH_SHORT).show();

                // Create an Intent to navigate to Teacher/HOD Leave Management System
                Intent intent = new Intent(cothirdyaerstudleavemanagementsystem.this, teacherleavemanagement.class);
                startActivity(intent);
            }
        });
    }
}
