package com.example.capstoneproject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class cothirdyearstudclassroom extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studclassroom); // Set the layout for this activity

        // Find the button and spinner by their IDs
        Button selectExamButton = findViewById(R.id.selectExamButton);
        Spinner yearSpinner = findViewById(R.id.yearSpinner);

        // Create a list of years for the spinner
        List<String> years = new ArrayList<>();
        years.add("Class Test 1 S24");
        years.add("Class Test 2 S24");

        // Create an ArrayAdapter to populate the spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, years);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearSpinner.setAdapter(adapter);

        // Set an OnClickListener on the "Select Exam" button
        selectExamButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toggle the visibility of the spinner
                if (yearSpinner.getVisibility() == View.GONE) {
                    yearSpinner.setVisibility(View.VISIBLE); // Show the spinner
                } else {
                    yearSpinner.setVisibility(View.GONE); // Hide the spinner
                }
            }
        });

        // Handle item selection in the spinner
        yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedYear = parent.getItemAtPosition(position).toString();
                // Perform an action with the selected year (e.g., display a toast)
                Toast.makeText(cothirdyearstudclassroom.this, "Selected Year: " + selectedYear, Toast.LENGTH_SHORT).show();

                // Show the subject selection dialog
                showSubjectSelectionDialog();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void showSubjectSelectionDialog() {
        // Inflate the dialog layout
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_select_subject, null);

        // Find the Spinner in the dialog layout
        Spinner subjectSpinner = dialogView.findViewById(R.id.subjectSpinner);

        // Create a list of subjects for the spinner
        List<String> subjects = new ArrayList<>();
        subjects.add("MGT");
        subjects.add("MAD");
        subjects.add("PYTHON");
        subjects.add("WBP");
        subjects.add("ETI");

        // Create an ArrayAdapter to populate the spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, subjects);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subjectSpinner.setAdapter(adapter);

        // Create the AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Subject")
                .setView(dialogView)
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        // Create the AlertDialog instance
        AlertDialog dialog = builder.create();

        // Set a listener for subject selection
        subjectSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Dynamically change the "OK" button to "Download PDF" button
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setVisibility(View.VISIBLE);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("Download PDF");
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    String selectedSubject = subjectSpinner.getSelectedItem().toString();
                    Toast.makeText(cothirdyearstudclassroom.this, "Downloading PDF for: " + selectedSubject, Toast.LENGTH_SHORT).show();
                    // Call the method to download the PDF
                    downloadPdf(selectedSubject);
                    dialog.dismiss(); // Close the dialog after initiating the download
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Show the dialog
        dialog.show();

        // Initially hide the "Download PDF" button
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setVisibility(View.GONE);
    }

    private void downloadPdf(String subject) {
        // Get the PDF URL based on the selected subject
        String pdfUrl = getPdfUrlForSubject(subject);

        // Start the download task
        new DownloadPdfTask().execute(pdfUrl);
    }

    private String getPdfUrlForSubject(String subject) {
        // Return the appropriate URL for each subject
        switch (subject) {
            case "MGT":
                return "https://example.com/pdfs/mgt.pdf";
            case "MAD":
                return "https://example.com/pdfs/mad.pdf";
            case "PYTHON":
                return "https://example.com/pdfs/python.pdf";
            case "WBP":
                return "https://example.com/pdfs/wbp.pdf";
            case "ETI":
                return "https://example.com/pdfs/eti.pdf";
            default:
                return null;
        }
    }

    private class DownloadPdfTask extends AsyncTask<String, Void, File> {

        @Override
        protected File doInBackground(String... urls) {
            String pdfUrl = urls[0];
            try {
                URL url = new URL(pdfUrl);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoOutput(true);
                urlConnection.connect();

                // Create a file in the Downloads directory
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "downloaded_" + System.currentTimeMillis() + ".pdf");
                FileOutputStream fileOutput = new FileOutputStream(file);
                InputStream inputStream = urlConnection.getInputStream();

                // Write the PDF data to the file
                byte[] buffer = new byte[1024];
                int bufferLength;
                while ((bufferLength = inputStream.read(buffer)) > 0) {
                    fileOutput.write(buffer, 0, bufferLength);
                }
                fileOutput.close();
                return file;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(File file) {
            if (file != null) {
                Toast.makeText(cothirdyearstudclassroom.this, "PDF downloaded to: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(cothirdyearstudclassroom.this, "Failed to download PDF", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
