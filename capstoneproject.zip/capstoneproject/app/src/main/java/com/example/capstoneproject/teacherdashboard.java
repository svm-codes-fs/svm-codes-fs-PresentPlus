package com.example.capstoneproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileNotFoundException;
import java.io.InputStream;

public class teacherdashboard extends AppCompatActivity {

    private String username, department, role;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "UserPrefs";
    private ImageView profileImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacherdashboard);

        // Get login data from intent
        username = getIntent().getStringExtra("username");
        department = getIntent().getStringExtra("department");
        role = getIntent().getStringExtra("role");

        // Save login data in SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("logged_username", username);
        editor.putString("logged_department", department);
        editor.putString("logged_role", role);
        editor.apply();

        // Initialize Profile Image and Load it from SharedPreferences
        profileImage = findViewById(R.id.profile_image);
        loadProfileImage();

        // Profile Image Click Listener (Go to Profile Page)
        profileImage.setOnClickListener(view -> {
            Toast.makeText(teacherdashboard.this, "Opening Profile", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(teacherdashboard.this, teacherprofile.class);
            startActivity(intent);
        });

        // Time Table Button
        ImageButton timetableButton = findViewById(R.id.imageButton_timetable);
        timetableButton.setOnClickListener(view -> {
            Intent intent = new Intent(teacherdashboard.this, teachertimetable.class);
            startActivity(intent);
        });

        // Attendance Button
        ImageButton attendanceButton = findViewById(R.id.imageButton_attendance);
        attendanceButton.setOnClickListener(view -> {
            Intent intent = new Intent(teacherdashboard.this, teacherattendance.class);
            startActivity(intent);
        });

        // Notification Button
        ImageButton notificationButton = findViewById(R.id.imageButton_notification);
        notificationButton.setOnClickListener(view -> {
            Intent intent = new Intent(teacherdashboard.this, teachernotification.class);
            startActivity(intent);
        });

        // Manage Students Button
        Button manageStudentsButton = findViewById(R.id.button_manage_students);
        manageStudentsButton.setOnClickListener(view -> {
            Intent intent = new Intent(teacherdashboard.this, teacherstudentmanagement.class);
            startActivity(intent);
        });

        // Attendance Record Button
        Button attendanceRecordButton = findViewById(R.id.button_attendance_record);
        attendanceRecordButton.setOnClickListener(view -> {
            Intent intent = new Intent(teacherdashboard.this, teacherattendancerecord.class);
            startActivity(intent);
        });
    }

    // Method to Load the Profile Image from SharedPreferences
    private void loadProfileImage() {
        String savedImageUri = sharedPreferences.getString(username + "_profile_image", null);
        if (savedImageUri != null) {
            try {
                Uri imageUri = Uri.parse(savedImageUri);
                InputStream imageStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(imageStream);
                profileImage.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to load profile image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Reload profile image when returning from the profile page
    @Override
    protected void onResume() {
        super.onResume();
        loadProfileImage();
    }
}
