package com.example.capstoneproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HODDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoddashboard);

        // Profile Image Click Listener
        ImageView profileImage = findViewById(R.id.hod_profile_image);
        profileImage.setOnClickListener(view -> {
            Toast.makeText(HODDashboard.this, "Opening Profile", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HODDashboard.this, hodprofile.class);
            startActivity(intent);
        });

        // Time Table Button
        ImageButton timetableButton = findViewById(R.id.hod_imageButton_timetable);
        timetableButton.setOnClickListener(view -> {
            Toast.makeText(HODDashboard.this, "Opening Time Table", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HODDashboard.this, hodtimetable.class);
            startActivity(intent);
        });

        // Attendance Button
        ImageButton attendanceButton = findViewById(R.id.hod_imageButton_attendance);
        attendanceButton.setOnClickListener(view -> {
            Toast.makeText(HODDashboard.this, "Opening Attendance", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HODDashboard.this, hodattendance.class);
            startActivity(intent);
        });

        // Notification Button
        ImageButton notificationButton = findViewById(R.id.hod_imageButton_notification);
        notificationButton.setOnClickListener(view -> {
            Toast.makeText(HODDashboard.this, "Opening Notifications", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HODDashboard.this, hodnotification.class);
            startActivity(intent);
        });

        // Manage Students Button
        Button manageStudentsButton = findViewById(R.id.hod_button_manage_students);
        manageStudentsButton.setOnClickListener(view -> {
            Toast.makeText(HODDashboard.this, "Opening Student Management", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HODDashboard.this, hodstudentmanagement.class);
            startActivity(intent);
        });

        // Leave Management Button
        Button leaveManagementButton = findViewById(R.id.hod_button_leave_management);
        leaveManagementButton.setOnClickListener(view -> {
            Toast.makeText(HODDashboard.this, "Opening Leave Management", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HODDashboard.this, hodleavemanagement.class);
            startActivity(intent);
        });

        // Attendance Record Button
        Button attendanceRecordButton = findViewById(R.id.hod_button_attendance_record);
        attendanceRecordButton.setOnClickListener(view -> {
            Toast.makeText(HODDashboard.this, "Opening Attendance Records", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HODDashboard.this, hodattendancerecord.class);
            startActivity(intent);
        });
    }
}
